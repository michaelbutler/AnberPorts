#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/Redneck Rampage"
export SDL_GAMECONTROLLERCONFIG="$(cat gamecontrollerdb.txt)"
LD_LIBRARY_PATH=./lib/ ./rednukem
unset SDL_GAMECONTROLLERCONFIG
