#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/spelunky"

# gl4es
export LIBGL_FB=4

# system
export LD_LIBRARY_PATH=$DIR/lib

# box86
export BOX86_ALLOWMISSINGLIBS=1
export BOX86_LD_LIBRARY_PATH=$DIR/lib
export BOX86_LIBGL=$DIR/lib/libGL.so.1
export BOX86_PATH=$DIR/bin

setarch linux32 -L $DIR/bin/box86 $DIR/spelunky 2>&1 | tee -a $DIR/log.txt &
sudo $DIR/bin/oga_controls