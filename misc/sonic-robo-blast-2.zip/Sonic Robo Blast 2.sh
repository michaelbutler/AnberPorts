#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/Sonic Robo Blast 2"
export SDL_GAMECONTROLLERCONFIG="$(cat gamecontrollerdb.txt)"
LD_LIBRARY_PATH=. ./srb2.elf
unset SDL_GAMECONTROLLERCONFIG
