#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/sdlpop"
export SDL_GAMECONTROLLERCONFIG="$(cat gamecontrollerdb.txt)"
LD_LIBRARY_PATH=. ./prince
unset SDL_GAMECONTROLLERCONFI
