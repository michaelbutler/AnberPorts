#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/Blood"
sudo ./oga_controls &
./nblood
pgrep -f oga_controls | sudo xargs kill -9
