#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/Blood"
export SDL_GAMECONTROLLERCONFIG="$(cat gamecontrollerdb.txt)"
sudo ./oga_controls &
LD_LIBRARY_PATH=./lib/ ./nblood
unset SDL_GAMECONTROLLERCONFIG
pgrep -f oga_controls | sudo xargs kill -9
