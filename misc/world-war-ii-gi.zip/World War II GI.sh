#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/World War II GI"
sudo ./oga_controls &
export SDL_GAMECONTROLLERCONFIG="$(cat gamecontrollerdb.txt)"
LD_LIBRARY_PATH=./lib/ ./rednukem 2>&1 | tee -a ./log.txt
unset SDL_GAMECONTROLLERCONFIG
pgrep -f oga_controls | sudo xargs kill -9
