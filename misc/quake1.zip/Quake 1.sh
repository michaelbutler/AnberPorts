#/bin/bash
/usr/local/bin/retroarch32 -L /home/ark/.config/retroarch32/cores/tyrquake_libretro.so /roms/ports/quake1/
