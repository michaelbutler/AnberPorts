#!/bin/bash
cd "$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/avp"
sudo ./oga_controls &
XDG_RUNTIME_DIR=/run/user/1002 ./avp 2>&1 | tee -a ./log.txt
pgrep -f oga_controls | sudo xargs kill -9
