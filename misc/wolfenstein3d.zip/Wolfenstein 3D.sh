#/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )/ecwolf"
/usr/local/bin/retroarch -L /home/ark/.config/retroarch/cores/ecwolf_libretro.so $DIR/WOLF3D.EXE 2>&1 | tee -a $DIR/log.txt